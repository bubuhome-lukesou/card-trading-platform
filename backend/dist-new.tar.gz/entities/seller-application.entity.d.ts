import { User } from './user.entity';
export declare enum SellerApplicationStatus {
    PENDING = "pending",
    APPROVED = "approved",
    REJECTED = "rejected"
}
export declare class SellerApplication {
    id: string;
    userId: string;
    user: User;
    email: string;
    nickname: string;
    password: string;
    storeName: string;
    storeDescription: string;
    phone: string;
    pickupInfo: string;
    pickupQrCode: string;
    status: SellerApplicationStatus;
    reviewedBy: string;
    reviewedAt: Date;
    rejectionReason: string;
    createdAt: Date;
    updatedAt: Date;
}
