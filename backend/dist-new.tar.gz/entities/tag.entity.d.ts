import { Product } from './product.entity';
export declare enum TagType {
    GENERAL = "general",
    PRODUCT_TYPE = "product_type"
}
export declare class Tag {
    id: number;
    name: string;
    slug: string;
    color: string;
    type: TagType;
    sortOrder: number;
    createdAt: Date;
    products: Product[];
}
