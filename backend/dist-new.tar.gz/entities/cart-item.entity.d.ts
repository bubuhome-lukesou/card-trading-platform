import { User } from './user.entity';
import { Product } from './product.entity';
export declare class CartItem {
    id: string;
    user: User;
    product: Product;
    quantity: number;
    createdAt: Date;
    updatedAt: Date;
}
