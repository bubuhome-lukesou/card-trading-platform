import { User } from './user.entity';
import { Product } from './product.entity';
export declare enum ReservationStatus {
    PENDING = "pending",
    DEPOSIT_PAID = "deposit_paid",
    CONFIRMED = "confirmed",
    CANCELLED = "cancelled",
    EXPIRED = "expired"
}
export declare class Reservation {
    id: string;
    productId: string;
    product: Product;
    buyerId: string;
    buyer: User;
    depositAmount: number;
    depositPaidAt: Date | null;
    status: ReservationStatus;
    expireTime: Date;
    createdAt: Date;
}
