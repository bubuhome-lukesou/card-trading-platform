import { User } from './user.entity';
import { Product } from './product.entity';
export declare enum OrderType {
    DIRECT_PURCHASE = "direct_purchase",
    BUY_NOW = "buy_now",
    AUCTION_WIN = "auction_win",
    RESERVATION_DEPOSIT = "reservation_deposit",
    RESERVATION_FULL = "reservation_full"
}
export declare enum OrderStatus {
    PENDING = "pending",
    PENDING_PAID = "pending_paid",
    PAID = "paid",
    CONFIRMED = "confirmed",
    SHIPPED = "shipped",
    DELIVERED = "delivered",
    CANCELLED = "cancelled",
    REFUNDED = "refunded"
}
export declare class Order {
    id: string;
    orderNumber: string;
    buyerId: string;
    buyer: User;
    sellerId: string;
    seller: User;
    productId: string;
    product: Product;
    type: OrderType;
    status: OrderStatus;
    totalPrice: number;
    shippingCost: number;
    platformFee: number;
    shippingAddress: string;
    trackingNumber: string;
    paymentMethod: string;
    paymentTime: Date;
    shippingTime: Date;
    deliveryTime: Date;
    notes: string;
    quantity: number;
    transferReceipt: string;
    transferTime: Date;
    balanceReceipt: string;
    balanceTime: Date;
    createdAt: Date;
    updatedAt: Date;
}
