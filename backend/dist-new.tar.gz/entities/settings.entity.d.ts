export declare class Settings {
    id: number;
    pickupInfo: string;
    pickupQrCode: string;
    updatedAt: Date;
}
