"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const typeorm_1 = require("typeorm");
const bcrypt = __importStar(require("bcrypt"));
const user_entity_1 = require("./entities/user.entity");
const AppDataSource = new typeorm_1.DataSource({
    type: 'mysql',
    host: process.env.DB_HOST || '127.0.0.1',
    port: parseInt(process.env.DB_PORT || '3306'),
    username: process.env.DB_USERNAME || 'card_admin',
    password: process.env.DB_PASSWORD || 'CardAuction2026!',
    database: process.env.DB_DATABASE || 'card_auction',
    entities: [user_entity_1.User],
    synchronize: false,
});
async function createSeller() {
    await AppDataSource.initialize();
    console.log('✅ Database connected');
    const userRepo = AppDataSource.getRepository(user_entity_1.User);
    const passwordHash = await bcrypt.hash('Seller123!', 10);
    let seller = await userRepo.findOne({ where: { email: 'seller_test@cardquest.com' } });
    if (!seller) {
        seller = await userRepo.save({
            email: 'seller_test@cardquest.com',
            nickname: 'TestSeller',
            password: passwordHash,
            role: user_entity_1.UserRole.SELLER,
            status: user_entity_1.UserStatus.ACTIVE,
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sellertest',
        });
        console.log('✅ Seller created!');
    }
    else {
        seller.password = passwordHash;
        seller.role = user_entity_1.UserRole.SELLER;
        seller.status = user_entity_1.UserStatus.ACTIVE;
        await userRepo.save(seller);
        console.log('✅ Seller updated!');
    }
    console.log('\n📝 Seller Account:');
    console.log('   Email: seller_test@cardquest.com');
    console.log('   Password: Seller123!');
    console.log('   Role: SELLER');
    console.log('   Status: ACTIVE');
    await AppDataSource.destroy();
}
createSeller().catch(console.error);
//# sourceMappingURL=create-seller.js.map