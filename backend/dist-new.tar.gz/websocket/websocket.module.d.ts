export declare class WebsocketModule {
}
