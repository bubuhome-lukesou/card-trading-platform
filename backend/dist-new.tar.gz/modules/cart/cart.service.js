"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CartService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const cart_item_entity_1 = require("../../entities/cart-item.entity");
const product_entity_1 = require("../../entities/product.entity");
let CartService = class CartService {
    constructor(cartRepo, productRepo) {
        this.cartRepo = cartRepo;
        this.productRepo = productRepo;
    }
    async findAll(userId) {
        return this.cartRepo.find({
            where: { user: { id: userId } },
            relations: ['product'],
            order: { createdAt: 'DESC' },
        });
    }
    async addItem(userId, productId, quantity = 1) {
        const product = await this.productRepo.findOne({ where: { id: productId } });
        if (!product) {
            throw new common_1.NotFoundException('Product not found');
        }
        const currentQty = product.quantity ?? 0;
        if (currentQty <= 0) {
            throw new common_1.NotFoundException('Out of stock');
        }
        const existing = await this.cartRepo.findOne({
            where: { user: { id: userId }, product: { id: productId } },
        });
        if (existing) {
            const newQty = existing.quantity + quantity;
            if (newQty > currentQty) {
                throw new common_1.NotFoundException(`Only ${currentQty} items available`);
            }
            existing.quantity = newQty;
            return this.cartRepo.save(existing);
        }
        if (quantity > currentQty) {
            throw new common_1.NotFoundException(`Only ${currentQty} items available`);
        }
        const cartItem = this.cartRepo.create({
            user: { id: userId },
            product: { id: productId },
            quantity,
        });
        return this.cartRepo.save(cartItem);
    }
    async removeItem(id, userId) {
        const item = await this.cartRepo.findOne({
            where: { id },
            relations: ['user'],
        });
        if (!item) {
            throw new common_1.NotFoundException('Cart item not found');
        }
        if (item.user.id !== userId) {
            throw new common_1.NotFoundException('Cart item not found');
        }
        await this.cartRepo.remove(item);
    }
    async updateItem(id, userId, quantity) {
        if (quantity < 1) {
            throw new common_1.NotFoundException('Quantity must be at least 1');
        }
        const item = await this.cartRepo.findOne({
            where: { id },
            relations: ['user', 'product'],
        });
        if (!item) {
            throw new common_1.NotFoundException('Cart item not found');
        }
        if (item.user.id !== userId) {
            throw new common_1.NotFoundException('Cart item not found');
        }
        const currentQty = item.product.quantity ?? 0;
        if (quantity > currentQty) {
            throw new common_1.NotFoundException(`Only ${currentQty} items available`);
        }
        item.quantity = quantity;
        return this.cartRepo.save(item);
    }
    async clearCart(userId) {
        const items = await this.cartRepo.find({
            where: { user: { id: userId } },
        });
        await this.cartRepo.remove(items);
    }
};
exports.CartService = CartService;
exports.CartService = CartService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(cart_item_entity_1.CartItem)),
    __param(1, (0, typeorm_1.InjectRepository)(product_entity_1.Product)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], CartService);
//# sourceMappingURL=cart.service.js.map