import { CartService } from './cart.service';
export declare class CartController {
    private cartService;
    constructor(cartService: CartService);
    getCart(req: any): Promise<import("../../entities/cart-item.entity").CartItem[]>;
    addItem(req: any, body: {
        productId: string;
        quantity?: number;
    }): Promise<import("../../entities/cart-item.entity").CartItem>;
    updateItem(id: string, req: any, body: {
        quantity: number;
    }): Promise<import("../../entities/cart-item.entity").CartItem>;
    removeItem(id: string, req: any): Promise<void>;
    clearCart(req: any): Promise<void>;
}
