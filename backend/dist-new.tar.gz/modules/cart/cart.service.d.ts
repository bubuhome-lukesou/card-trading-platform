import { Repository } from 'typeorm';
import { CartItem } from '../../entities/cart-item.entity';
import { Product } from '../../entities/product.entity';
export declare class CartService {
    private cartRepo;
    private productRepo;
    constructor(cartRepo: Repository<CartItem>, productRepo: Repository<Product>);
    findAll(userId: string): Promise<CartItem[]>;
    addItem(userId: string, productId: string, quantity?: number): Promise<CartItem>;
    removeItem(id: string, userId: string): Promise<void>;
    updateItem(id: string, userId: string, quantity: number): Promise<CartItem>;
    clearCart(userId: string): Promise<void>;
}
