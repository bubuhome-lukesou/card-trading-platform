import { TagType } from '../../../entities/tag.entity';
export declare class CreateTagDto {
    name: string;
    slug?: string;
    color?: string;
    type?: TagType;
    sortOrder?: number;
}
export declare class UpdateTagDto {
    name?: string;
    slug?: string;
    color?: string;
    type?: TagType;
    sortOrder?: number;
}
