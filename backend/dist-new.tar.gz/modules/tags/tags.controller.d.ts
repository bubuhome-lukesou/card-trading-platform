import { TagsService } from './tags.service';
import { CreateTagDto, UpdateTagDto } from './dto/tag.dto';
export declare class TagsController {
    private readonly tagsService;
    constructor(tagsService: TagsService);
    findAll(): Promise<import("../../entities/tag.entity").Tag[]>;
    findOne(id: number): Promise<import("../../entities/tag.entity").Tag>;
    create(dto: CreateTagDto): Promise<import("../../entities/tag.entity").Tag>;
    update(id: number, dto: UpdateTagDto): Promise<import("../../entities/tag.entity").Tag>;
    remove(id: number): Promise<void>;
}
