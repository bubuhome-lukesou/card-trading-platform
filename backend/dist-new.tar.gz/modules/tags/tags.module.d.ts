export declare class TagsModule {
}
