import { Repository } from 'typeorm';
import { Tag } from '../../entities/tag.entity';
import { CreateTagDto, UpdateTagDto } from './dto/tag.dto';
export declare class TagsService {
    private readonly tagRepo;
    constructor(tagRepo: Repository<Tag>);
    findAll(): Promise<Tag[]>;
    findOne(id: number): Promise<Tag>;
    findBySlug(slug: string): Promise<Tag>;
    create(dto: CreateTagDto): Promise<Tag>;
    update(id: number, dto: UpdateTagDto): Promise<Tag>;
    remove(id: number): Promise<void>;
    findOrCreate(names: string[]): Promise<Tag[]>;
}
