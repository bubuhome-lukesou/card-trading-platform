export declare class BidsModule {
}
