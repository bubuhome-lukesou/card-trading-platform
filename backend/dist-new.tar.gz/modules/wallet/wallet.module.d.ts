export declare class WalletModule {
}
