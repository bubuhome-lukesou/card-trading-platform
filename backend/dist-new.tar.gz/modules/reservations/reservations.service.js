"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReservationsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const reservation_entity_1 = require("../../entities/reservation.entity");
const product_entity_1 = require("../../entities/product.entity");
const order_entity_1 = require("../../entities/order.entity");
const orders_service_1 = require("../orders/orders.service");
let ReservationsService = class ReservationsService {
    constructor(reservationRepo, productRepo, orderRepo, ordersService) {
        this.reservationRepo = reservationRepo;
        this.productRepo = productRepo;
        this.orderRepo = orderRepo;
        this.ordersService = ordersService;
    }
    async create(productId, buyerId, depositAmount, expireTime) {
        const product = await this.productRepo.findOne({ where: { id: productId } });
        if (!product) {
            throw new common_1.NotFoundException('Product not found');
        }
        if (product.listingType !== product_entity_1.ListingType.RESERVATION_ONLY) {
            throw new common_1.BadRequestException('Product is not available for reservation');
        }
        if (product.reservationMax) {
            const count = await this.reservationRepo.count({
                where: { productId, status: reservation_entity_1.ReservationStatus.DEPOSIT_PAID }
            });
            if (count >= product.reservationMax) {
                throw new common_1.BadRequestException('Reservation limit reached');
            }
        }
        const existing = await this.reservationRepo.findOne({
            where: { productId, buyerId, status: reservation_entity_1.ReservationStatus.DEPOSIT_PAID }
        });
        if (existing) {
            throw new common_1.BadRequestException('You have already made a reservation for this product');
        }
        const reservation = this.reservationRepo.create({
            productId,
            buyerId,
            depositAmount,
            expireTime,
            status: reservation_entity_1.ReservationStatus.PENDING,
        });
        const savedReservation = await this.reservationRepo.save(reservation);
        const order = await this.ordersService.create({
            buyerId,
            sellerId: product.sellerId,
            productId,
            type: order_entity_1.OrderType.RESERVATION_DEPOSIT,
            status: order_entity_1.OrderStatus.PENDING,
            totalPrice: depositAmount,
            quantity: 1,
            notes: `預約訂金 - 預約ID: ${savedReservation.id}`,
        });
        return { reservation: savedReservation, order };
    }
    async confirmDeposit(reservationId) {
        const reservation = await this.findOne(reservationId);
        reservation.status = reservation_entity_1.ReservationStatus.DEPOSIT_PAID;
        reservation.depositPaidAt = new Date();
        return this.reservationRepo.save(reservation);
    }
    async findByProduct(productId) {
        return this.reservationRepo.find({
            where: { productId },
            relations: ['buyer'],
            order: { createdAt: 'ASC' }
        });
    }
    async findByBuyer(buyerId) {
        return this.reservationRepo.find({
            where: { buyerId },
            relations: ['product'],
            order: { createdAt: 'DESC' }
        });
    }
    async findBySeller(sellerId) {
        return this.reservationRepo
            .createQueryBuilder('r')
            .innerJoin('r.product', 'p')
            .where('p.sellerId = :sellerId', { sellerId })
            .leftJoinAndSelect('r.buyer', 'buyer')
            .leftJoinAndSelect('r.product', 'product')
            .orderBy('r.createdAt', 'DESC')
            .getMany();
    }
    async findOne(id) {
        const reservation = await this.reservationRepo.findOne({
            where: { id },
            relations: ['product', 'buyer']
        });
        if (!reservation) {
            throw new common_1.NotFoundException('Reservation not found');
        }
        return reservation;
    }
    async cancel(id, userId) {
        const reservation = await this.findOne(id);
        const product = await this.productRepo.findOne({ where: { id: reservation.productId } });
        if (reservation.buyerId !== userId && product?.sellerId !== userId) {
            throw new common_1.ForbiddenException('You do not have permission to cancel this reservation');
        }
        reservation.status = reservation_entity_1.ReservationStatus.CANCELLED;
        return this.reservationRepo.save(reservation);
    }
    async getReservationCount(productId) {
        return this.reservationRepo.count({
            where: { productId, status: reservation_entity_1.ReservationStatus.DEPOSIT_PAID }
        });
    }
    async getProduct(productId) {
        const product = await this.productRepo.findOne({ where: { id: productId } });
        if (!product) {
            throw new common_1.NotFoundException('Product not found');
        }
        return product;
    }
};
exports.ReservationsService = ReservationsService;
exports.ReservationsService = ReservationsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(reservation_entity_1.Reservation)),
    __param(1, (0, typeorm_1.InjectRepository)(product_entity_1.Product)),
    __param(2, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(3, (0, common_1.Inject)((0, common_1.forwardRef)(() => orders_service_1.OrdersService))),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        orders_service_1.OrdersService])
], ReservationsService);
//# sourceMappingURL=reservations.service.js.map