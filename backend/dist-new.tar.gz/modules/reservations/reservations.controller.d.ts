import { ReservationsService } from './reservations.service';
export declare class ReservationsController {
    private readonly reservationsService;
    constructor(reservationsService: ReservationsService);
    create(body: {
        productId: string;
    }, req: any): Promise<{
        reservation: import("../../entities/reservation.entity").Reservation;
        order: import("../../entities").Order;
    }>;
    findMy(req: any): Promise<import("../../entities/reservation.entity").Reservation[]>;
    findByProduct(productId: string): Promise<import("../../entities/reservation.entity").Reservation[]>;
    findBySeller(req: any): Promise<import("../../entities/reservation.entity").Reservation[]>;
    findOne(id: string): Promise<import("../../entities/reservation.entity").Reservation>;
    confirmDeposit(id: string): Promise<import("../../entities/reservation.entity").Reservation>;
    cancel(id: string, req: any): Promise<import("../../entities/reservation.entity").Reservation>;
}
