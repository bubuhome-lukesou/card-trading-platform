import { Repository } from 'typeorm';
import { Reservation } from '../../entities/reservation.entity';
import { Product } from '../../entities/product.entity';
import { Order } from '../../entities/order.entity';
import { OrdersService } from '../orders/orders.service';
export declare class ReservationsService {
    private reservationRepo;
    private productRepo;
    private orderRepo;
    private ordersService;
    constructor(reservationRepo: Repository<Reservation>, productRepo: Repository<Product>, orderRepo: Repository<Order>, ordersService: OrdersService);
    create(productId: string, buyerId: string, depositAmount: number, expireTime: Date): Promise<{
        reservation: Reservation;
        order: Order;
    }>;
    confirmDeposit(reservationId: string): Promise<Reservation>;
    findByProduct(productId: string): Promise<Reservation[]>;
    findByBuyer(buyerId: string): Promise<Reservation[]>;
    findBySeller(sellerId: string): Promise<Reservation[]>;
    findOne(id: string): Promise<Reservation>;
    cancel(id: string, userId: string): Promise<Reservation>;
    getReservationCount(productId: string): Promise<number>;
    getProduct(productId: string): Promise<Product>;
}
