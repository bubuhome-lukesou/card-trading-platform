export declare class ReservationsModule {
}
