export declare class SellerApplicationsModule {
}
