import { Repository } from 'typeorm';
import { SellerApplication } from '../../entities/seller-application.entity';
import { User } from '../../entities/user.entity';
export declare class SellerApplicationsService {
    private applicationRepo;
    private userRepo;
    constructor(applicationRepo: Repository<SellerApplication>, userRepo: Repository<User>);
    createWithAccount(dto: {
        email: string;
        nickname: string;
        password: string;
        storeName: string;
        storeDescription?: string;
        phone?: string;
        pickupInfo?: string;
        pickupQrCode?: string;
    }): Promise<SellerApplication>;
    getByEmail(email: string): Promise<SellerApplication | null>;
    getPendingApplications(): Promise<SellerApplication[]>;
    getAllApplications(page?: number, limit?: number): Promise<{
        data: SellerApplication[];
        total: number;
    }>;
    approve(applicationId: string): Promise<SellerApplication>;
    reject(applicationId: string, reason?: string): Promise<SellerApplication>;
}
