"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SellerApplicationsController = void 0;
const common_1 = require("@nestjs/common");
const seller_applications_service_1 = require("./seller-applications.service");
let SellerApplicationsController = class SellerApplicationsController {
    constructor(applicationsService) {
        this.applicationsService = applicationsService;
    }
    create(body) {
        return this.applicationsService.createWithAccount(body);
    }
    getStatusByEmail(email) {
        return this.applicationsService.getByEmail(email);
    }
    getPendingApplications() {
        return this.applicationsService.getPendingApplications();
    }
    getAllApplications(page = 1, limit = 20) {
        return this.applicationsService.getAllApplications(+page, +limit);
    }
    approve(id) {
        return this.applicationsService.approve(id);
    }
    reject(id, reason) {
        return this.applicationsService.reject(id, reason);
    }
};
exports.SellerApplicationsController = SellerApplicationsController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SellerApplicationsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('status'),
    __param(0, (0, common_1.Query)('email')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SellerApplicationsController.prototype, "getStatusByEmail", null);
__decorate([
    (0, common_1.Get)('pending'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], SellerApplicationsController.prototype, "getPendingApplications", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], SellerApplicationsController.prototype, "getAllApplications", null);
__decorate([
    (0, common_1.Patch)(':id/approve'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SellerApplicationsController.prototype, "approve", null);
__decorate([
    (0, common_1.Patch)(':id/reject'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('reason')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], SellerApplicationsController.prototype, "reject", null);
exports.SellerApplicationsController = SellerApplicationsController = __decorate([
    (0, common_1.Controller)('seller-applications'),
    __metadata("design:paramtypes", [seller_applications_service_1.SellerApplicationsService])
], SellerApplicationsController);
//# sourceMappingURL=seller-applications.controller.js.map