import { SellerApplicationsService } from './seller-applications.service';
export declare class SellerApplicationsController {
    private applicationsService;
    constructor(applicationsService: SellerApplicationsService);
    create(body: {
        email: string;
        nickname: string;
        password: string;
        storeName: string;
        storeDescription?: string;
        phone?: string;
        pickupInfo?: string;
        pickupQrCode?: string;
    }): Promise<import("../../entities").SellerApplication>;
    getStatusByEmail(email: string): Promise<import("../../entities").SellerApplication>;
    getPendingApplications(): Promise<import("../../entities").SellerApplication[]>;
    getAllApplications(page?: number, limit?: number): Promise<{
        data: import("../../entities").SellerApplication[];
        total: number;
    }>;
    approve(id: string): Promise<import("../../entities").SellerApplication>;
    reject(id: string, reason?: string): Promise<import("../../entities").SellerApplication>;
}
