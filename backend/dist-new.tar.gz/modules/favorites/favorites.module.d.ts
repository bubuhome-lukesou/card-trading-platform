export declare class FavoritesModule {
}
