export declare class AiModule {
}
