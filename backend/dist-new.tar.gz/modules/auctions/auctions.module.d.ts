export declare class AuctionsModule {
}
